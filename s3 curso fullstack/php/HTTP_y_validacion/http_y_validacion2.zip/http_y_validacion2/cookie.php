<?php
setcookie('testcookie', "mila", time() + 60);

var_dump($_COOKIE);

 ?>
