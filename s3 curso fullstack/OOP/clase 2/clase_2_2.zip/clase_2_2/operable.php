<?php

    interface Operable {

        public function operar($num1, $num2);

}

?>