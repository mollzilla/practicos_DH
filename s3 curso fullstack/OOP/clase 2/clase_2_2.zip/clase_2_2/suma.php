<?php

class Suma implements Operable {
    public function operar($num1, $num2) {
        return $num1 + $num2;
    }

}



?>